from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
import os
from pyspark.sql import DataFrame
import time
import logging
from datetime import datetime




KEYSPACE = "ineuron"
TABLE="employee"

#kafka server detail
KAFKA_BOOTSTRAP_SERVER="kafka:9092"
KAFKA_TOPIC = "employee"

#Cassandra database connectivity credentails
CASSANDRA_HOST="cassandra"
CASSANDRA_USER="cassandra"
CASSANDRA_PASSWORD="cassandra"





# deptColumns = ["dept_name","dept_id"]
# df = spark.createDataFrame(data=dept, schema = deptColumns)

# df.show(truncate  = False)

# df.write\
# .format("org.apache.spark.sql.cassandra")\
# .mode('append')\
# .options(table="demo", keyspace="demo")\
# .save()


# def dataFrameToCassandaDbTable(df,keyspace:str,table:str):
#     (df.write.format("org.apache.spark.sql.cassandra").mode('append').options(table=table, keyspace=keyspace).save())
#     return "inserted succesfully"

##### if __name__=="__main__":

def writeToCassandrafunc():
    spark = (SparkSession.builder
                 .config("spark.cassandra.connection.host","cassandra")
                 .config("spark.cassandra.auth.username","cassandra")
                 .config("spark.cassandra.auth.password","cassandra")
                 .appName("demo").getOrCreate()
                 )
    
    # dept = [(10,"Finance"),(20,"Marketing"),(30,"Sales"),(40,"IT") ,(50,"HR")]
    # dept = [(11,"Finance"),(22,"Marketing"),(33,"Sales"),(44,"IT") ,(55,"HR")]
    # deptColumns = ["dept_id","dept_name"]
    

    # df = spark.createDataFrame(data=dept, schema = deptColumns)
    
    df = spark.read.json('results2.json',multiLine=True)
    df = df.drop('teamInfo').drop('score')
    df = df.withColumnRenamed('date','date_')



    df = df.select('date_','hasSquad','id','matchEnded','matchStarted','matchType','name','series_id','status','venue')
    
    df.show(truncate  = False)
    
    # df.rdd.saveToCassandra("cricket", "cricket_data3")
    
    # write data to cassandra database
    try:
        (df.write.format("org.apache.spark.sql.cassandra").mode('append').options(table=table, keyspace=keyspace).save())
    except Exception :
        print("exception occured")

    df_cassandra = (spark.read
        .format("org.apache.spark.sql.cassandra")
        .options(table="cricket_data6",keyspace="cricket")
        .load())  

    df_cassandra.show(truncate  = False)
    #Print the schema 
    df.printSchema()