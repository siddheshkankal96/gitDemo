import json
import requests

url = 'https://api.cricapi.com/v1/currentMatches?apikey=8990f916-8107-4f70-9e8e-dcbd9639b687&offset=0'

# download  = requests.get(url).text
# json_data = json.loads(download)

# # print((json_data['data']))
# # for i in range(len(json_data['data'])):
#     # print((json_data['data'][1]))
    
# with open('./json_data2.json',mode='a') as f:
#     for i in range(len(json_data['data'])):
#     # print((json_data['data'][1]))
#         f.write(str(json_data['data'][i]))


####download  = requests.get(url)
# print(type(download.json()['data']))
# print(type(len(download.json()['data'])))
# # print(len(download.json()['data']))

####data = download.json()['data']

####data2 = json.dumps(data)
# print(type(data2))
# print(data2)

#####records = json.loads(data2)

####file = open('./pyspark_data/results2.json','a')
# print(type(records))

####json.dump(records,file,indent=6)
####file.close()



def json_api_data_import(url:str):
    download  = requests.get(url)
    
    data = download.json()['data']
    
    data2 = json.dumps(data)
    
    records = json.loads(data2)
    
    file = open('./pyspark_data/results2.json','a')


    json.dump(records,file,indent=6)
    file.close()
    

# if __name__=="__main__":
#     json_api_data_import(url)

