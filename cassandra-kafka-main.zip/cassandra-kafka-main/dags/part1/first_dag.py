try:

    from datetime import timedelta
    from airflow import DAG
    from airflow.operators.python_operator import PythonOperator
    from airflow.operators.email_operator import EmailOperator
    from datetime import datetime
    import requests
    import json
    import argparse
   
    import pandas as pd
    from typing import List
    import os.path
    import csv
    # from process1 import writeToCassandrafunc
    # from process1 import json_api_data_import
    # from pyspark.sql import SparkSession
    # from pyspark.sql.functions import *
    # from pyspark.sql.types import *
    # import os
    # from pyspark.sql import DataFrame
    # import time
    # import logging
    # from datetime import datetime
    
    print("All Dag modules are ok ......")





    KEYSPACE = "cricket"
    TABLE="cricket_data6"

    #kafka server detail
    KAFKA_BOOTSTRAP_SERVER="kafka:9092"
    KAFKA_TOPIC = "employee"

    #Cassandra database connectivity credentails
    CASSANDRA_HOST="cassandra"
    CASSANDRA_USER="cassandra"
    CASSANDRA_PASSWORD="cassandra"

except Exception as e:
    print("Error  {} ".format(e))


def writeToCassandrafunc():
    spark = (SparkSession.builder
                 .config("spark.cassandra.connection.host","cassandra")
                 .config("spark.cassandra.auth.username","cassandra")
                 .config("spark.cassandra.auth.password","cassandra")
                 .appName("demo").getOrCreate()
                 )
    
    # dept = [(10,"Finance"),(20,"Marketing"),(30,"Sales"),(40,"IT") ,(50,"HR")]
    # dept = [(11,"Finance"),(22,"Marketing"),(33,"Sales"),(44,"IT") ,(55,"HR")]
    # deptColumns = ["dept_id","dept_name"]
    

    # df = spark.createDataFrame(data=dept, schema = deptColumns)
    
    df = spark.read.json('./op_files/results2.json',multiLine=True)
    df = df.drop('teamInfo').drop('score')
    df = df.withColumnRenamed('date','date_')



    df = df.select('date_','hasSquad','id','matchEnded','matchStarted','matchType','name','series_id','status','venue')
    
    df.show(truncate  = False)
    
    # df.rdd.saveToCassandra("cricket", "cricket_data3")
    
    # write data to cassandra database
    try:
        (df.write.format("org.apache.spark.sql.cassandra").mode('append').options(table='crickect_data6', keyspace='crickect').save())
    except Exception :
        print("exception occured")

    df_cassandra = (spark.read
        .format("org.apache.spark.sql.cassandra")
        .options(table="cricket_data6",keyspace="cricket")
        .load())  

    df_cassandra.show(truncate  = False)
    #Print the schema 
    df.printSchema()
    



def json_api_data_import():
    url = 'https://api.cricapi.com/v1/currentMatches?apikey=8990f916-8107-4f70-9e8e-dcbd9639b687&offset=0'

    download  = requests.get(url)
    
    data = download.json()['data']
    
    data2 = json.dumps(data)
    
    records = json.loads(data2)
    
    file = open('./op_files/results2.json','a')


    json.dump(records,file,indent=6)
    file.close()
    
    
    
    
def first_function():
    print("Hello world this works ")
    return "successfuly done"


with DAG(dag_id="first_dag",
         schedule_interval="@daily",
         default_args={
             "owner": "airflow",
             "start_date": datetime(2023, 1, 27),
             "retries": 1,
             "retry_delay": timedelta(minutes=1)
         },
         catchup=False) as dag:

    first_function = PythonOperator(
        task_id="first_function",
        python_callable=first_function
    )
    writeToCassandrafunc = PythonOperator(
        task_id="writeToCassandrafunc",
        python_callable=writeToCassandrafunc
    )
    json_api_data_import = PythonOperator(
        task_id="json_api_data_import",
        python_callable=json_api_data_import
    )
    
first_function>>json_api_data_import>>writeToCassandrafunc
















